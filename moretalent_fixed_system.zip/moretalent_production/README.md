# MoreTalent — DG Ventures ATS

MoreTalent is the DG Ventures Talent Acquisition system. This package is a **deployable production-oriented web application foundation**: secure password hashing, role-based access, private document storage, recruiter assignment, candidate application, automatic video-request email, interviews, scorecards, decisions, offers, onboarding, reports, audit foundation, Docker support and an optional IMAP worker for candidate video replies.

## Recruitment workflow

Requisition → Vacancy → Candidate Application → CV → automatic 2-minute video request → Video Received → Recruiter Interview /10 → Hiring Manager Interview /10 → Final Decision → Offer → Hire → Onboarding.

There is **no assessment stage** and **no separate reference-check stage**. The application only asks whether DG Ventures may contact the candidate's professional references.

## Important: credentials

Never put real passwords, SMTP passwords, API keys or cloud credentials into source code or chat. Copy `.env.example` to `.env` and fill it locally/on the hosting provider's secret manager.

The bootstrap admin email defaults to `sherwindavids06@gmail.com`. Set `MORETALENT_BOOTSTRAP_PASSWORD` to a strong temporary password before first startup and change it immediately after login.

## Fastest way to run on Windows

1. Install Python 3.11+.
2. Extract the ZIP.
3. Double-click `run_windows.bat`.
4. Open `http://127.0.0.1:5000`.
5. Sign in using the bootstrap credentials configured in `.env`.

## Mac/Linux

Run `./run_mac_linux.sh`, then open `http://127.0.0.1:5000`.

## Docker

1. Install Docker Desktop.
2. Copy `.env.example` to `.env`.
3. Replace the secret values.
4. Run `docker compose up -d --build`.
5. Open `http://localhost:5000`.

Data and uploaded CV/video files are persisted in the Docker volume `moretalent_data`.

## Email/video automation

Outgoing candidate email is enabled when SMTP variables are configured. The application email contains the candidate's unique `APP-YYYY-...` reference and asks the candidate to reply with a maximum two-minute introductory video.

The included `inbound_email_worker.py` can monitor a dedicated IMAP mailbox. It finds the application reference in the email subject/body, extracts a supported video attachment, stores it privately and marks the candidate's application as `Video Received`.

For a production Microsoft 365/Google Workspace deployment, the preferred next step is to replace basic IMAP credentials with the provider's OAuth/API integration or an approved inbound-email webhook. Do not store mailbox passwords in the repository.

## Production deployment

Recommended setup:

- Managed Linux/cloud host or container platform
- HTTPS/TLS
- Persistent managed database (PostgreSQL recommended for a larger deployment)
- Private object storage for CVs/videos
- SMTP/API email provider
- OAuth/SSO if DG Ventures requires it
- Automated backups
- Malware scanning of uploaded files
- Central logging/monitoring
- Data retention/deletion policy
- Security review and penetration testing before live candidate use

The included Docker configuration is suitable for a controlled deployment but should be paired with managed database/object storage and a reverse proxy/HTTPS in a real production environment.

## What is still organisation-specific

No software can safely invent DG Ventures' production email credentials, cloud credentials, retention policy, SSO settings or legal/privacy configuration. Those are configured when DG Ventures provides the chosen hosting/email identity details.
