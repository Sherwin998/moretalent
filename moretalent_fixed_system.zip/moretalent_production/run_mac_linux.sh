#!/usr/bin/env bash
set -e
command -v python3 >/dev/null || { echo 'Python 3.11+ is required.'; exit 1; }
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
python app.py
