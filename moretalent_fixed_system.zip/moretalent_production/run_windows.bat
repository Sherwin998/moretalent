@echo off
setlocal
where python >nul 2>nul || (echo Python 3.11+ is required. Install it from python.org and run this again.&pause&exit /b 1)
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
python app.py
