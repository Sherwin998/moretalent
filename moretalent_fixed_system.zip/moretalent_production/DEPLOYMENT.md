# MoreTalent deployment checklist

## Recommended first deployment

For DG Ventures, deploy MoreTalent to a managed Linux/cloud VM or container service with HTTPS and a persistent disk. A small VM is sufficient for the first internal release.

### 1. Domain
Create a DNS record such as:

`moretalent.dgventureslimited.com`

Point it at the production host. Do not share DNS credentials in chat.

### 2. Server
Install Docker and Docker Compose on the server. Copy the MoreTalent project to the server, then:

```bash
cp .env.example .env
# edit .env with real secrets
# then
sudo docker compose up -d --build
```

Put an HTTPS reverse proxy (Caddy, Nginx, or the hosting provider's managed proxy) in front of port 5000.

### 3. Secrets
Generate a long random `MORETALENT_SECRET_KEY`. Set a unique bootstrap password. Set SMTP credentials through the hosting provider's secret store/environment, not in Git.

### 4. Email
Set `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD` and `SMTP_FROM` to the approved DG Ventures mailbox/service.

The candidate video request uses the assigned recruiter's address as `Reply-To`, so candidate replies are directed to the recruiter handling that vacancy.

### 5. Inbound video replies
Run the optional worker as a separate service/process:

```bash
python inbound_email_worker.py
```

It monitors the configured mailbox, finds the `APP-YYYY-...` application reference in the message, saves the first supported video attachment privately, marks the application `Video Received`, and emails the assigned recruiter a notification.

For Microsoft 365 or Google Workspace, use OAuth/API access rather than storing a personal mailbox password where possible.

### 6. Backups
Back up both `/app/data/moretalent.db` and `/app/data/uploads/`. Test restoration before go-live.

### 7. Security before live candidate data
- HTTPS only
- Change bootstrap password
- Use strong unique secrets
- Restrict server access
- Add malware scanning for uploads
- Add central logs and monitoring
- Define POPIA/privacy retention and deletion rules with DG Ventures
- Test access permissions for Admin, Recruiter and Hiring Manager accounts
- Perform security testing before opening the application link publicly

### 8. Go-live test
Run one complete test candidate:

Requisition → vacancy → public application → CV → automatic video request → candidate reply → video matching → recruiter notification → recruiter interview → recruiter score → hiring manager interview → hiring manager score → decision → offer → onboarding.

Only after this test passes should the public vacancy links be distributed.
