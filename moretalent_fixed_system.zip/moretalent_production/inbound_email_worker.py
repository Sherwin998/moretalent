"""Optional IMAP worker for candidate video replies.

Configure IMAP_* in .env. The candidate must keep the application reference
(e.g. APP-2026-ABC123) in the email subject/body. The worker stores the first
supported video attachment and marks the application as Video Received.
Run separately from the web process: python inbound_email_worker.py
"""
import os, imaplib, email, time, re
from pathlib import Path
from datetime import datetime
from app import db, UP

EXTS={'mp4','mov','webm','avi','m4v'}
REF=re.compile(r'APP-\d{4}-[A-Z0-9-]+', re.I)

def process():
    host=os.environ.get('IMAP_HOST'); user=os.environ.get('IMAP_USER'); password=os.environ.get('IMAP_PASSWORD'); folder=os.environ.get('IMAP_FOLDER','INBOX')
    if not all([host,user,password]): return False,'IMAP not configured'
    m=imaplib.IMAP4_SSL(host, int(os.environ.get('IMAP_PORT','993'))); m.login(user,password); m.select(folder)
    typ,data=m.search(None,'UNSEEN')
    c=db()
    for num in data[0].split():
        typ,msgdata=m.fetch(num,'(RFC822)'); msg=email.message_from_bytes(msgdata[0][1]); text=(msg.get('Subject','')+'\n')
        for part in msg.walk():
            if part.get_content_type()=='text/plain':
                try:text += '\n'+part.get_payload(decode=True).decode(errors='ignore')
                except Exception: pass
        match=REF.search(text)
        if not match: continue
        ref=match.group(0).upper(); app=c.execute('''SELECT a.id,a.reference,v.recruiter_id,u.email recruiter_email,u.name recruiter_name,c.first_name,c.last_name FROM applications a JOIN vacancies v ON v.id=a.vacancy_id LEFT JOIN users u ON u.id=v.recruiter_id JOIN candidates c ON c.id=a.candidate_id WHERE a.reference=?''',(ref,)).fetchone()
        if not app: continue
        saved=None
        for part in msg.walk():
            fn=part.get_filename()
            if not fn or '.' not in fn: continue
            ext=fn.rsplit('.',1)[-1].lower()
            if ext in EXTS:
                safe='inbound_'+ref+'_'+re.sub(r'[^A-Za-z0-9_.-]','_',fn); path=UP/safe; path.write_bytes(part.get_payload(decode=True)); saved=safe; break
        if saved:
            now=datetime.utcnow().isoformat()
            c.execute('UPDATE applications SET video_file=?,status="Video Received",video_received_at=? WHERE id=?',(saved,now,app['id'])); c.commit()
            if app['recruiter_email']:
                from app import send_email
                send_email(app['recruiter_email'], f'MoreTalent — video received ({app["reference"]})', f'A new introductory video has been received for {app["first_name"]} {app["last_name"]}. Application reference: {app["reference"]}. Open the candidate profile in MoreTalent to review it.')
        m.store(num,'+FLAGS','\\Seen')
    c.close(); m.logout(); return True,'processed'

if __name__=='__main__':
    while True:
        try: process()
        except Exception as e: print('Inbound worker error:',e,flush=True)
        time.sleep(int(os.environ.get('POLL_SECONDS','60')))
