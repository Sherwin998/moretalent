import os, re, sqlite3, secrets, smtplib, ssl
from datetime import datetime
from email.message import EmailMessage
from functools import wraps
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE = Path(__file__).resolve().parent
DB = Path(os.environ.get('MORETALENT_DB', BASE / 'data' / 'moretalent.db'))
UP = Path(os.environ.get('MORETALENT_UPLOADS', BASE / 'data' / 'uploads'))
DB.parent.mkdir(parents=True, exist_ok=True); UP.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get('MORETALENT_SECRET_KEY', secrets.token_hex(32))
app.config.update(
    MAX_CONTENT_LENGTH=int(os.environ.get('MAX_UPLOAD_MB','50')) * 1024 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_SECURE=os.environ.get('MORETALENT_HTTPS','0') == '1',
)
ALLOWED = {'pdf','doc','docx','mp4','mov','webm','avi','m4v'}
VIDEO_EXTS = {'mp4','mov','webm','avi','m4v'}


def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def init():
    c = db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL, active INTEGER DEFAULT 1, created_at TEXT);
    CREATE TABLE IF NOT EXISTS requisitions(id INTEGER PRIMARY KEY, code TEXT UNIQUE, title TEXT, department TEXT, manager TEXT, positions INTEGER, location TEXT, employment TEXT, start_date TEXT, priority TEXT, reason TEXT, requirements TEXT, status TEXT, recruiter_id INTEGER, created_at TEXT);
    CREATE TABLE IF NOT EXISTS vacancies(id INTEGER PRIMARY KEY, req_id INTEGER, code TEXT UNIQUE, title TEXT, description TEXT, requirements TEXT, location TEXT, employment TEXT, closing_date TEXT, status TEXT DEFAULT 'Draft', recruiter_id INTEGER, manager TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS candidates(id INTEGER PRIMARY KEY, first_name TEXT,last_name TEXT,email TEXT,phone TEXT,location TEXT,current_employer TEXT,current_position TEXT,experience TEXT,notice TEXT,linkedin TEXT,portfolio TEXT,ref_consent TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS applications(id INTEGER PRIMARY KEY,candidate_id INTEGER,vacancy_id INTEGER,reference TEXT UNIQUE,status TEXT DEFAULT 'Applied',cv_file TEXT,video_file TEXT,screening TEXT,created_at TEXT, video_requested_at TEXT, video_received_at TEXT);
    CREATE TABLE IF NOT EXISTS interviews(id INTEGER PRIMARY KEY,application_id INTEGER,type TEXT,date TEXT,time TEXT,interviewer TEXT,interviewer_email TEXT,status TEXT DEFAULT 'Scheduled',score REAL, recommendation TEXT,comments TEXT);
    CREATE TABLE IF NOT EXISTS offers(id INTEGER PRIMARY KEY,application_id INTEGER,start_date TEXT,salary TEXT,employment TEXT,status TEXT DEFAULT 'Draft',created_at TEXT);
    CREATE TABLE IF NOT EXISTS onboarding(id INTEGER PRIMARY KEY,application_id INTEGER,start_date TEXT,status TEXT DEFAULT 'Not Started',progress INTEGER DEFAULT 0,created_at TEXT);
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,user_id INTEGER,action TEXT,entity TEXT,entity_id INTEGER,created_at TEXT);
    ''')
    if not c.execute('SELECT 1 FROM users LIMIT 1').fetchone():
        email=os.environ.get('MORETALENT_BOOTSTRAP_EMAIL','sherwindavids06@gmail.com').lower()
        pw=os.environ.get('MORETALENT_BOOTSTRAP_PASSWORD','ChangeMe-Immediately-2026!')
        c.execute('INSERT INTO users(name,email,password,role,created_at) VALUES(?,?,?,?,?)',('Sherwin Davids',email,generate_password_hash(pw),'admin',datetime.utcnow().isoformat()))
    c.commit(); c.close()


def log(action, entity, eid):
    c=db(); c.execute('INSERT INTO audit(user_id,action,entity,entity_id,created_at) VALUES(?,?,?,?,?)',(session.get('uid'),action,entity,eid,datetime.utcnow().isoformat())); c.commit(); c.close()

def login_required(f):
    @wraps(f)
    def w(*a,**kw):
        if not session.get('uid'): return redirect(url_for('login',next=request.path))
        return f(*a,**kw)
    return w

def roles(*rs):
    def deco(f):
        @wraps(f)
        def w(*a,**kw):
            if session.get('role') not in rs: abort(403)
            return f(*a,**kw)
        return w
    return deco

def file_save(file):
    if not file or not file.filename: return None
    ext=file.filename.rsplit('.',1)[-1].lower() if '.' in file.filename else ''
    if ext not in ALLOWED: raise ValueError('Unsupported file type. Allowed: PDF, DOC, DOCX and common video formats.')
    name=f"{secrets.token_hex(16)}_{secure_filename(file.filename)}"; file.save(UP/name); return name

def send_email(to, subject, body, reply_to=None, attachment_path=None):
    host=os.environ.get('SMTP_HOST'); port=int(os.environ.get('SMTP_PORT','587')); user=os.environ.get('SMTP_USER'); password=os.environ.get('SMTP_PASSWORD'); sender=os.environ.get('SMTP_FROM') or user
    if not (host and user and password and sender):
        return False, 'SMTP is not configured.'
    msg=EmailMessage(); msg['From']=sender; msg['To']=to; msg['Subject']=subject
    if reply_to: msg['Reply-To']=reply_to
    msg.set_content(body)
    if attachment_path:
        p=Path(attachment_path); data=p.read_bytes(); msg.add_attachment(data, maintype='application', subtype='octet-stream', filename=p.name)
    try:
        if os.environ.get('SMTP_TLS','1')=='1':
            with smtplib.SMTP(host,port,timeout=20) as s:
                s.starttls(context=ssl.create_default_context()); s.login(user,password); s.send_message(msg)
        else:
            with smtplib.SMTP(host,port,timeout=20) as s: s.login(user,password); s.send_message(msg)
        return True, 'Sent'
    except Exception as e: return False, str(e)

def recruiter_for_vacancy(c, vid):
    return c.execute('SELECT u.* FROM vacancies v LEFT JOIN users u ON u.id=v.recruiter_id WHERE v.id=?',(vid,)).fetchone()

@app.context_processor
def ctx(): return {'user':session}

@app.route('/')
def home(): return redirect(url_for('dashboard')) if session.get('uid') else redirect(url_for('login'))

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        c=db(); u=c.execute('SELECT * FROM users WHERE email=? AND active=1',(request.form['email'].strip().lower(),)).fetchone(); c.close()
        if u and check_password_hash(u['password'],request.form['password']):
            session.clear(); session.update(uid=u['id'],name=u['name'],role=u['role'],email=u['email']); return redirect(request.args.get('next') or url_for('dashboard'))
        flash('Invalid email or password.')
    return render_template('login.html')
@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    c=db(); stats={'reqs':c.execute("SELECT count(*) n FROM requisitions WHERE status!='Closed'").fetchone()['n'],'apps':c.execute('SELECT count(*) n FROM applications').fetchone()['n'],'interviews':c.execute("SELECT count(*) n FROM interviews WHERE status='Scheduled'").fetchone()['n'],'offers':c.execute("SELECT count(*) n FROM offers WHERE status IN ('Draft','Sent','Pending')").fetchone()['n'],'videos':c.execute("SELECT count(*) n FROM applications WHERE video_file IS NULL AND status IN ('Applied','Screening')").fetchone()['n']}; recent=c.execute('''SELECT a.reference,v.title,c.first_name||' '||c.last_name name,a.status,a.id FROM applications a JOIN candidates c ON c.id=a.candidate_id JOIN vacancies v ON v.id=a.vacancy_id ORDER BY a.id DESC LIMIT 10''').fetchall(); c.close(); return render_template('dashboard.html',stats=stats,recent=recent)

@app.route('/requisitions')
@login_required
def requisitions():
    c=db(); rows=c.execute('SELECT * FROM requisitions ORDER BY id DESC').fetchall(); c.close(); return render_template('requisitions.html',rows=rows)
@app.route('/requisitions/new',methods=['GET','POST'])
@login_required
@roles('admin','recruiter')
def new_requisition():
    if request.method=='POST':
        c=db(); code='REQ-'+datetime.now().strftime('%Y')+'-'+secrets.token_hex(3).upper(); cur=c.execute('''INSERT INTO requisitions(code,title,department,manager,positions,location,employment,start_date,priority,reason,requirements,status,recruiter_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(code,request.form['title'],request.form['department'],request.form['manager'],request.form['positions'],request.form['location'],request.form['employment'],request.form['start_date'],request.form['priority'],request.form['reason'],request.form['requirements'],'Submitted',session['uid'],datetime.utcnow().isoformat())); c.commit(); eid=cur.lastrowid;c.close();log('Created requisition','requisition',eid);flash('Requisition created.');return redirect(url_for('requisitions'))
    return render_template('requisition_form.html')

@app.route('/vacancies')
@login_required
def vacancies():
    c=db(); rows=c.execute('SELECT v.*,u.name recruiter_name FROM vacancies v LEFT JOIN users u ON u.id=v.recruiter_id ORDER BY v.id DESC').fetchall(); c.close(); return render_template('vacancies.html',rows=rows)
@app.route('/vacancies/new',methods=['GET','POST'])
@login_required
@roles('admin','recruiter')
def new_vacancy():
    c=db(); reqs=c.execute("SELECT * FROM requisitions WHERE status IN ('Submitted','Approved') ORDER BY id DESC").fetchall(); recruiters=c.execute("SELECT * FROM users WHERE role IN ('admin','recruiter') AND active=1 ORDER BY name").fetchall()
    if request.method=='POST':
        r=c.execute('SELECT * FROM requisitions WHERE id=?',(request.form['req_id'],)).fetchone(); rid=int(request.form.get('recruiter_id') or session['uid']); code='VAC-'+datetime.now().strftime('%Y')+'-'+secrets.token_hex(3).upper(); cur=c.execute('''INSERT INTO vacancies(req_id,code,title,description,requirements,location,employment,closing_date,status,recruiter_id,manager,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',(r['id'],code,request.form['title'],request.form['description'],request.form['requirements'],r['location'],r['employment'],request.form['closing_date'],'Live',rid,r['manager'],datetime.utcnow().isoformat()));c.commit();eid=cur.lastrowid;c.close();log('Created vacancy','vacancy',eid);flash('Vacancy published.');return redirect(url_for('vacancies'))
    c.close(); return render_template('vacancy_form.html',reqs=reqs,recruiters=recruiters)

@app.route('/candidates')
@login_required
def candidates():
    c=db(); rows=c.execute('''SELECT a.id,a.reference,a.status,c.first_name||' '||c.last_name name,c.email,v.title,a.video_file FROM applications a JOIN candidates c ON c.id=a.candidate_id JOIN vacancies v ON v.id=a.vacancy_id ORDER BY a.id DESC''').fetchall();c.close();return render_template('candidates.html',rows=rows)
@app.route('/candidate/<int:aid>')
@login_required
def candidate(aid):
    c=db(); a=c.execute('''SELECT a.*,c.*,v.title vacancy,v.code vcode,u.name recruiter_name,u.email recruiter_email FROM applications a JOIN candidates c ON c.id=a.candidate_id JOIN vacancies v ON v.id=a.vacancy_id LEFT JOIN users u ON u.id=v.recruiter_id WHERE a.id=?''',(aid,)).fetchone();
    if not a: c.close(); abort(404)
    ints=c.execute('SELECT * FROM interviews WHERE application_id=? ORDER BY id',(aid,)).fetchall(); offer=c.execute('SELECT * FROM offers WHERE application_id=? ORDER BY id DESC LIMIT 1',(aid,)).fetchone(); c.close(); return render_template('candidate.html',a=a,ints=ints,offer=offer)

@app.route('/apply/<int:vid>',methods=['GET','POST'])
def apply(vid):
    c=db();v=c.execute('SELECT * FROM vacancies WHERE id=? AND status="Live"',(vid,)).fetchone();
    if not v: c.close(); abort(404)
    if request.method=='POST':
        try: cv=file_save(request.files.get('cv'))
        except ValueError as e: c.close();flash(str(e));return redirect(url_for('apply',vid=vid))
        cur=c.execute('INSERT INTO candidates(first_name,last_name,email,phone,location,current_employer,current_position,experience,notice,linkedin,portfolio,ref_consent,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(request.form['first_name'],request.form['last_name'],request.form['email'].lower(),request.form['phone'],request.form['location'],request.form['employer'],request.form['position'],request.form['experience'],request.form['notice'],request.form['linkedin'],request.form['portfolio'],request.form['ref_consent'],datetime.utcnow().isoformat()));cid=cur.lastrowid; ref='APP-'+datetime.now().strftime('%Y')+'-'+secrets.token_hex(3).upper();cur=c.execute('INSERT INTO applications(candidate_id,vacancy_id,reference,cv_file,screening,created_at) VALUES(?,?,?,?,?,?)',(cid,vid,ref,cv,request.form['screening'],datetime.utcnow().isoformat()));aid=cur.lastrowid
        recruiter=recruiter_for_vacancy(c,vid); c.commit(); c.close()
        if recruiter:
            subject=f'MoreTalent — 2-minute introductory video requested ({ref})'
            body=f"Hello {request.form['first_name']},\n\nThank you for applying for {v['title']} at DG Ventures.\n\nYour application reference is {ref}. As the next step, please reply to this email with a maximum 2-minute introductory video telling us about yourself, your experience and your interest in the role.\n\nPlease keep the video under 50 MB where possible. Your reply should keep the subject line so MoreTalent can automatically match the video to your application.\n\nKind regards,\n{recruiter['name']}\nTalent Acquisition | DG Ventures"
            ok,msg=send_email(request.form['email'],subject,body,reply_to=recruiter['email'])
            c=db(); c.execute('UPDATE applications SET video_requested_at=? WHERE id=?',(datetime.utcnow().isoformat(),aid)); c.commit(); c.close()
        return render_template('confirmation.html',ref=ref,email=request.form['email'])
    c.close();return render_template('apply.html',v=v)

@app.route('/application/<int:aid>/video',methods=['POST'])
@login_required
@roles('admin','recruiter')
def video(aid):
    c=db();
    try: f=file_save(request.files.get('video'))
    except ValueError as e: c.close();flash(str(e));return redirect(url_for('candidate',aid=aid))
    if not f or Path(f).suffix.lower().lstrip('.') not in VIDEO_EXTS: c.close();flash('Please upload a video file.');return redirect(url_for('candidate',aid=aid))
    c.execute('UPDATE applications SET video_file=?,status=?,video_received_at=? WHERE id=?',(f,'Video Received',datetime.utcnow().isoformat(),aid));c.commit();c.close();log('Video received','application',aid);flash('Video attached to candidate profile.');return redirect(url_for('candidate',aid=aid))

@app.route('/application/<int:aid>/interview',methods=['POST'])
@login_required
@roles('admin','recruiter','hiring_manager')
def interview(aid):
    if request.form['type']=='Hiring Manager' and session['role'] not in ('admin','recruiter','hiring_manager'): abort(403)
    c=db(); c.execute('INSERT INTO interviews(application_id,type,date,time,interviewer,interviewer_email,status) VALUES(?,?,?,?,?,?,?)',(aid,request.form['type'],request.form['date'],request.form['time'],request.form['interviewer'],request.form.get('interviewer_email',''),'Scheduled'));c.commit();c.close();log('Interview scheduled','application',aid);return redirect(url_for('candidate',aid=aid))
@app.route('/interview/<int:iid>/score',methods=['POST'])
@login_required
@roles('admin','recruiter','hiring_manager')
def score(iid):
    c=db();i=c.execute('SELECT * FROM interviews WHERE id=?',(iid,)).fetchone();
    if not i: c.close();abort(404)
    score=float(request.form['score']);
    if score<0 or score>10: c.close();flash('Score must be between 0 and 10.');return redirect(url_for('candidate',aid=i['application_id']))
    next_status='Hiring Manager Interview' if i['type']=='Recruiter' else 'Final Decision'; c.execute('UPDATE interviews SET score=?,recommendation=?,comments=?,status="Completed" WHERE id=?',(score,request.form['recommendation'],request.form['comments'],iid)); c.execute('UPDATE applications SET status=? WHERE id=?',(next_status,i['application_id']));c.commit();c.close();log('Interview score submitted','interview',iid);return redirect(url_for('candidate',aid=i['application_id']))

@app.route('/application/<int:aid>/decision',methods=['POST'])
@login_required
@roles('admin','recruiter','hiring_manager')
def decision(aid):
    d=request.form['decision']; c=db(); c.execute('UPDATE applications SET status=? WHERE id=?',(d,aid));
    if d=='Hire': c.execute('INSERT INTO onboarding(application_id,start_date,status,progress,created_at) SELECT ?,?,"Not Started",0,? WHERE NOT EXISTS(SELECT 1 FROM onboarding WHERE application_id=?)',(aid,request.form.get('start_date',''),datetime.utcnow().isoformat(),aid))
    c.commit();c.close();log('Final decision: '+d,'application',aid);return redirect(url_for('candidate',aid=aid))
@app.route('/application/<int:aid>/offer',methods=['POST'])
@login_required
@roles('admin','recruiter')
def offer(aid):
    c=db();c.execute('INSERT INTO offers(application_id,start_date,salary,employment,status,created_at) VALUES(?,?,?,?,?,?)',(aid,request.form['start_date'],request.form['salary'],request.form['employment'],'Pending',datetime.utcnow().isoformat()));c.execute('UPDATE applications SET status="Offer" WHERE id=?',(aid,));c.commit();c.close();log('Offer created','application',aid);return redirect(url_for('candidate',aid=aid))

@app.route('/interviews')
@login_required
def interviews():
    c=db(); rows=c.execute('''SELECT i.*,a.reference,c.first_name||' '||c.last_name candidate,v.title vacancy FROM interviews i JOIN applications a ON a.id=i.application_id JOIN candidates c ON c.id=a.candidate_id JOIN vacancies v ON v.id=a.vacancy_id ORDER BY i.date,i.time''').fetchall(); c.close(); return render_template('interviews.html',rows=rows)
@app.route('/offers')
@login_required
def offers():
    c=db(); rows=c.execute('''SELECT o.*,a.reference,c.first_name||' '||c.last_name candidate,v.title vacancy FROM offers o JOIN applications a ON a.id=o.application_id JOIN candidates c ON c.id=a.candidate_id JOIN vacancies v ON v.id=a.vacancy_id ORDER BY o.id DESC''').fetchall(); c.close(); return render_template('offers.html',rows=rows)
@app.route('/onboarding')
@login_required
def onboarding():
    c=db(); rows=c.execute('''SELECT o.*,a.reference,c.first_name||' '||c.last_name candidate,v.title vacancy FROM onboarding o JOIN applications a ON a.id=o.application_id JOIN candidates c ON c.id=a.candidate_id JOIN vacancies v ON v.id=a.vacancy_id ORDER BY o.id DESC''').fetchall(); c.close(); return render_template('onboarding.html',rows=rows)
@app.route('/reports')
@login_required
def reports():
    c=db(); data={'applications':c.execute('SELECT count(*) n FROM applications').fetchone()['n'],'hires':c.execute("SELECT count(*) n FROM applications WHERE status='Hire'").fetchone()['n'],'offers':c.execute('SELECT count(*) n FROM offers').fetchone()['n'],'avg_score':c.execute('SELECT round(avg(score),1) n FROM interviews WHERE score IS NOT NULL').fetchone()['n'] or 0}; c.close(); return render_template('reports.html',data=data)

@app.route('/settings')
@login_required
@roles('admin')
def settings():
    c=db();users=c.execute('SELECT id,name,email,role,active FROM users ORDER BY id').fetchall();c.close();return render_template('settings.html',users=users)
@app.route('/settings/user',methods=['POST'])
@login_required
@roles('admin')
def add_user():
    c=db();
    try:c.execute('INSERT INTO users(name,email,password,role,created_at) VALUES(?,?,?,?,?)',(request.form['name'],request.form['email'].lower(),generate_password_hash(request.form['password']),request.form['role'],datetime.utcnow().isoformat()));c.commit();flash('User added.')
    except sqlite3.IntegrityError: flash('Email already exists.')
    c.close();return redirect(url_for('settings'))
@app.route('/settings/user/<int:uid>/toggle',methods=['POST'])
@login_required
@roles('admin')
def toggle_user(uid):
    if uid==session['uid']: flash('You cannot deactivate your own account.'); return redirect(url_for('settings'))
    c=db(); c.execute('UPDATE users SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?',(uid,));c.commit();c.close();return redirect(url_for('settings'))
@app.route('/settings/password',methods=['POST'])
@login_required
def change_password():
    c=db();u=c.execute('SELECT * FROM users WHERE id=?',(session['uid'],)).fetchone();
    if not check_password_hash(u['password'],request.form['current']): c.close();flash('Current password is incorrect.');return redirect(url_for('settings'))
    c.execute('UPDATE users SET password=? WHERE id=?',(generate_password_hash(request.form['new']),session['uid']));c.commit();c.close();flash('Password changed.');return redirect(url_for('settings'))

@app.route('/secure-file/<path:name>')
@login_required
def secure_file(name):
    # Files are never public; access is only through authenticated staff.
    if '..' in Path(name).parts: abort(404)
    return send_from_directory(UP,name,as_attachment=False)

@app.errorhandler(413)
def too_large(e): return 'Upload too large. Please keep files within the configured limit.', 413

if __name__=='__main__':
    init(); app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)),debug=os.environ.get('FLASK_DEBUG','0')=='1')
